import java.awt.EventQueue;

import GUI.ContactInputFrame;


public class Start {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
			
				
		try {
			ContactInputFrame frame = new ContactInputFrame();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
}
}

		
	


